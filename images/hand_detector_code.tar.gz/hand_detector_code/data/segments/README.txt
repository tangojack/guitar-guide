In this directory store the super-pixel segments of the test images. This 
directory will be populated by running process_gPb.m in the root directory.