In this directory store all the results for face detection.
The face detections should be stored column wise with the 
rows representing (lower x, higher x, lower y, higher y) 
co-ordinates of the face bounding box for every detection.
