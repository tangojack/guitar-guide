In this directory store all the test images.
