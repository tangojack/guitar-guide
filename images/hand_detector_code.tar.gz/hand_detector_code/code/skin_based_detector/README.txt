This directory contains the code for hand hypothesis generation using the 
colour information. 

To use the code, first run getSkinRegions, which will detect and store the 
skin regions in the folder 'skinregions'.

Then run getSkinBoxes, which will process the detected skin regions and 
will stored hypothesised hand bounding boxes in the folder 'boxes'.